const inputName = document.querySelector('#name');
const pEl = document.querySelector('#name-user');
const inputColor = document.querySelector('#color');
const divEl = document.querySelector('#card');
const latinRegex = /^[A-Za-z\s\-]+$/;

inputName.addEventListener('input', function () {
  const fullName = inputName.value.trim();

  // 1. Проверка: поле пустое
  if (fullName === '') {
    inputName.setCustomValidity('Заполните это поле');
    inputName.reportValidity();
    pEl.textContent = '';
    return;
  }

  // 2. Проверка: только латиница
  if (!latinRegex.test(fullName)) {
    inputName.setCustomValidity('Введите имя и фамилию только латиницей');
    inputName.reportValidity();
    pEl.textContent = '';
    return;
  }

  // 3. Проверка: один пробел между фамилией и именем
  const parts = fullName.split(' ');
  if (parts.length !== 2 || parts[0] === '' || parts[1] === '') {
    inputName.setCustomValidity(
      'Между фамилией и именем должен быть один пробел'
    );
    inputName.reportValidity();
    pEl.textContent = '';
    return;
  }

  const surname = parts[0];
  const firstname = parts[1];

  // 4. Проверка: длина имени и фамилии
  if (surname.length < 2 || firstname.length < 2) {
    inputName.setCustomValidity(
      'Имя и фамилия должны быть не короче двух символов'
    );
    inputName.reportValidity();
    pEl.textContent = '';
    return;
  }

  // 5. Проверка: никаких лишних символов
  const cleaned = `${surname} ${firstname}`;
  if (fullName !== cleaned) {
    inputName.setCustomValidity(
      'Не должно быть лишних символов после имени и фамилии'
    );
    inputName.reportValidity();
    pEl.textContent = '';
    return;
  }
  inputName.setCustomValidity('');
  pEl.textContent = `${firstname} ${surname}`;
});

inputColor.addEventListener('input', function () {
  const selectedColor = inputColor.value;
  divEl.style.background = `linear-gradient(180deg, rgba(255, 255, 255, 0.9) 0%, ${selectedColor} 60%, ${selectedColor} 100%)`;
});
