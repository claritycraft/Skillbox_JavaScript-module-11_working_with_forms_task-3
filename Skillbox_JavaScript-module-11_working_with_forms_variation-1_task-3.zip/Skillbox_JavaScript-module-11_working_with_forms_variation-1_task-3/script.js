const card = document.getElementById("card");
const cardText = document.getElementById("cardText");
const cardColor = document.getElementById("cardColor");

cardText.addEventListener("input", () => {
  card.textContent = cardText.value || "Ваша карта";
});

cardText.addEventListener("focus", () => {
  cardText.style.border = "2px solid blue";
  cardText.style.backgroundColor = "#e0f0ff";
});

cardText.addEventListener("blur", () => {
  cardText.style.border = "1px solid black";
  cardText.style.backgroundColor = "white";
});

cardColor.addEventListener("change", () => {
  card.style.backgroundColor = cardColor.value;
});
